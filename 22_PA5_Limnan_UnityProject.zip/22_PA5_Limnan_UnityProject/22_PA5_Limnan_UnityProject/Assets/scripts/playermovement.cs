﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class playermovement : MonoBehaviour
{

    float hMoveSpeed = 10;
    float vMoveSpeed = 10;
    int coin=4;
    public Text score;
    // Start is called before the first frame update
    void Start()
    {
       
    }
        // Update is called once per frame
        void Update()
        {
        float hMovement = Input.GetAxis("Horizontal") * hMoveSpeed;
        float vMovement = Input.GetAxis("Vertical") * vMoveSpeed;
        score.text = "Coin left: " + coin;

        transform.Translate(new Vector3(hMovement*Time.deltaTime, 0, vMovement*Time.deltaTime));
        if (coin == 0)
        {
            SceneManager.LoadScene("Game Win");
        }
        
    }
    private void OnCollisionEnter(Collision collision)
    {
        
        if (collision.gameObject.tag == "Coin")
        {
            coin -= 1;
            print("hit");
            Destroy(collision.gameObject);
        }
        else if (collision.gameObject.tag == "death wall")
        {
            SceneManager.LoadScene("Game Lose");
        }
    }

}
